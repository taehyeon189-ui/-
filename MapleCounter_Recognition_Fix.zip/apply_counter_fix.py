"""Offline, backed-up source patch for the tested 1.0.19 counter."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from datetime import datetime
import zipfile


def apply(root, bundle):
    root = Path(root).resolve()
    if not (root/'maple_loot_counter.py').is_file() or not (root/'run.bat').is_file():
        raise RuntimeError('Extract this ZIP into your existing counter folder (the folder with run.bat).')
    with zipfile.ZipFile(bundle) as z:
        manifest = json.loads(z.read('manifest.json'))
        files = {}
        for name, info in manifest.items():
            if Path(name).name != name or not name.endswith('.py'):
                raise RuntimeError('Invalid patch path.')
            data = z.read(name)
            if hashlib.sha256(data).hexdigest() != info['new']:
                raise RuntimeError('Damaged patch. Download the ZIP again.')
            compile(data, name, 'exec')
            files[name] = data
    sys.path.insert(0, str(root))
    from instance_lock import InstanceLock
    lock = InstanceLock(root/'settings.json')
    try:
        for name, info in manifest.items():
            target = root/name
            if target.is_symlink() or not target.is_file():
                raise RuntimeError('Missing source file: '+name)
            actual = hashlib.sha256(target.read_bytes()).hexdigest()
            if actual not in (info['old'], info['new']):
                raise RuntimeError('Different program version: '+name+'. No files changed. This patch targets 1.0.19.')
        backup = root/'update_backups'/('repair_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        backup.mkdir(parents=True)
        for name in files:
            shutil.copy2(root/name, backup/name)
        for name in ('settings.json','settings.json.bak'):
            if (root/name).is_file():shutil.copy2(root/name,backup/name)
        changed = []
        try:
            for name, data in files.items():
                fd, temp = tempfile.mkstemp(dir=root, prefix='.repair_')
                try:
                    with os.fdopen(fd,'wb') as out:
                        out.write(data);out.flush();os.fsync(out.fileno())
                    os.replace(temp, root/name)
                    changed.append(name)
                finally:
                    if os.path.exists(temp):os.unlink(temp)
        except Exception:
            for name in reversed(changed):shutil.copy2(backup/name,root/name)
            raise
        print('Repair installed. Existing records were preserved.')
        print('Backup:',backup)
        return backup
    finally:
        lock.close()

if __name__ == '__main__':
    try:
        root=Path(__file__).resolve().parent
        apply(root, root/'counter_fix_payload.zip')
    except Exception as exc:
        print('REPAIR NOT INSTALLED:',str(exc))
        sys.exit(1)
