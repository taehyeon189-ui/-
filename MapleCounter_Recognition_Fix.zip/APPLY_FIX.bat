@echo off
setlocal
cd /d "%~dp0"
if exist ".venv_ocr\Scripts\python.exe" (
  ".venv_ocr\Scripts\python.exe" apply_counter_fix.py
) else (
  py -3 apply_counter_fix.py
)
if errorlevel 1 (
  echo Close the counter and check the message above.
  pause
  exit /b 1
)
call run.bat
